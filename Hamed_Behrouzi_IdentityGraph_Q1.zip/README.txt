Hamed Behrouzi — Identity Graph Mirror (Q1)
DOI: 10.5281/zenodo.17405925
Publisher: Hamed Behrouzi AI Identity Lab
License: CC BY 4.0 (Creative Commons Attribution 4.0 International)
Description:
Structured dataset describing Hamed Behrouzi’s verified identity graph, aligned with Wikidata, IMDb, and AI Ethical Interface.

More info:
https://hamedbehrouzi.com
https://doi.org/10.5281/zenodo.17405925
